# TGS 1.0.1
## Bug Fixes
* `LearnTgs::TGS()` now handles input where true networks are time-varying.

# TGS 1.0.0
* First CRAN release
