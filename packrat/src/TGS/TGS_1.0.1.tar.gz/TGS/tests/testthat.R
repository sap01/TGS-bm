library(testthat)
library(TGS)

test_check("TGS")
